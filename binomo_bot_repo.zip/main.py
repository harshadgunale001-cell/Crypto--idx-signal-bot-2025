import time
import requests

def send_signal_to_telegram(message: str):
    telegram_token = "YOUR_TELEGRAM_BOT_TOKEN"
    chat_id = "YOUR_CHAT_ID"
    url = f"https://api.telegram.org/bot{telegram_token}/sendMessage"
    data = {"chat_id": chat_id, "text": message}
    requests.post(url, data=data)

def main():
    while True:
        # यहां अपना signal generate करने का logic डालो
        signal = "UP"   # Example signal
        send_signal_to_telegram(f"Signal: {signal} | Asset: CRYPTO_IDX | Timeframe: 1m")
        time.sleep(60)  # हर 1 min बाद नया signal

if __name__ == "__main__":
    main()
